const bool SpeedToolsActiveOnLaunch = true;

const FName SaveState1 = ActionNames::SwingAttach;
const FName SaveState2 = ActionNames::FindOtherPlayer;
const FName LoadState1 = ActionNames::MovementSprintToggle;
const FName LoadState2 = ActionNames::SwingAttach;
const FName TeleportOther1 = ActionNames::Cancel;
const FName TeleportOther2 = ActionNames::FindOtherPlayer;
