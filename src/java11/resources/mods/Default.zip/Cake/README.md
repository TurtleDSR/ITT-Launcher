Cake systems are large gameplay sections that span longer amounts of time and involve a lot of systems to create coherent experience.

Delicious Includes:
- Peanuts
- Vino
- Rice
