Vino systems represent distinct gameplay moments that can used in levels or by larger Cake systems.

Delicious Includes:
- Peanuts
- Rice