Rice systems do not relate directly to gameplay or level design, but are still required to implement specific other systems.

Delicious Includes:
- None