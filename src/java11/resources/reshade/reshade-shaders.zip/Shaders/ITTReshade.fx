/**
 * ITT Reshade
 */

#include "ReShadeUI.fxh"
#include "ReShade.fxh"
#include "LinearGammaWorkflow.fxh"

 /**
 * Lift Gamma Gain version 1.1
 * by 3an and CeeJay.dk
 */

uniform bool LinearGamma
<	__UNIFORM_INPUT_BOOL1
    ui_text = "Gamma:";
	ui_label = "Linear Gamma";
> = false;

uniform float Gamma < __UNIFORM_SLIDER_FLOAT1
	ui_min = 0.0; ui_max = 3.0;
	ui_label = "Gamma";
	ui_tooltip = "Adjust gamma.";
> = float3(1.0, 1.0, 1.0);

uniform float3 RGB_Gamma < __UNIFORM_SLIDER_FLOAT3
	ui_min = 0.5; ui_max = 1.5;
	ui_label = "Gamma Correction";
	ui_tooltip = "Adjust midtones for red, green and blue.";
> = float3(1.0, 1.0, 1.0);

uniform float contrast <
    ui_label = "Contrast";
    ui_tooltip = "Contrast";
    ui_text = " ";
    ui_type = "slider";
    ui_min = -0.5;
    ui_max = 0.5;
    > = 0.0;
uniform float brightness <
    ui_label = "Brightness";
    ui_tooltip = "Brightness";
    ui_type = "slider";
    ui_min = -0.5;
    ui_max = 0.5;
    > = 0.0;
uniform float vibrance <
    ui_label = "Vibrance";
    ui_tooltip = "Vibrance";
    ui_type = "slider";
    ui_min = 0;
    ui_max = 0.5;
    > = 0.0;

uniform float sharp_strength < __UNIFORM_SLIDER_FLOAT1
	ui_min = 0; ui_max = 1.0;
	ui_label = "Sharpen";
    ui_text = " ";
	ui_tooltip = "Strength of the sharpening";

> = 0.0;
static const float sharp_clamp = 1.0;
static const float offset_bias = 0.4;



uniform bool SharpenBefore
<	__UNIFORM_INPUT_BOOL1
	ui_label = "Apply sharpen before everything";
> = false;

#define CoefLuma float3(0.2126, 0.7152, 0.0722)      // BT.709 & sRBG luma coefficient (Monitors and HD Television)
//#define CoefLuma float3(0.299, 0.587, 0.114)       // BT.601 luma coefficient (SD Television)
//#define CoefLuma float3(1.0/3.0, 1.0/3.0, 1.0/3.0) // Equal weight coefficient


float getAvgColor( float3 col )
{
    return dot( col.xyz, float3( 0.333333f, 0.333334f, 0.333333f ));
}

float3 blendLuma( float3 base, float3 blend )
{
    float lumbase     = getAvgColor( base.xyz );
    float lumblend    = getAvgColor( blend.xyz );
    float ldiff       = lumblend - lumbase;
    float3 color      = base.xyz + ldiff;

    float lum         = getAvgColor( color.xyz );
    float mincol      = min( min( color.x, color.y ), color.z );
    float maxcol      = max( max( color.x, color.y ), color.z );
    color.xyz         = ( mincol < 0.0f ) ? lum + (( color.xyz - lum ) * lum ) / ( lum - mincol ) : color.xyz;
    color.xyz         = ( maxcol > 1.0f ) ? lum + (( color.xyz - lum ) * ( 1.0f - lum )) / ( maxcol - lum ) : color.xyz;
    return color;
}

float3 sl( float3 c, float3 b )
{ 
    return b < 0.5f ? ( 2.0f * c * b + c * c * ( 1.0f - 2.0f * b )) : ( sqrt( c ) * ( 2.0f * b - 1.0f ) + 2.0f * c * ( 1.0f - b ));
}



float3 ITTReshadePass(float4 pos : SV_Position, float2 tex : TEXCOORD) : SV_Target
{
    //
    // Sharpening
    // 

    float3 color = tex2D(ReShade::BackBuffer, tex).rgb;

    // -- Combining the strength and luma multipliers --
	float3 sharp_strength_luma = (CoefLuma * sharp_strength); //I'll be combining even more multipliers with it later on

	float3 blur_ori = tex2D(ReShade::BackBuffer, tex + float2(BUFFER_PIXEL_SIZE.x, -BUFFER_PIXEL_SIZE.y) * 0.5 * offset_bias).rgb; // South East
    blur_ori += tex2D(ReShade::BackBuffer, tex - BUFFER_PIXEL_SIZE * 0.5 * offset_bias).rgb;  // South West
    blur_ori += tex2D(ReShade::BackBuffer, tex + BUFFER_PIXEL_SIZE * 0.5 * offset_bias).rgb; // North East
    blur_ori += tex2D(ReShade::BackBuffer, tex - float2(BUFFER_PIXEL_SIZE.x, -BUFFER_PIXEL_SIZE.y) * 0.5 * offset_bias).rgb; // North West

    blur_ori *= 0.25;  // ( /= 4) Divide by the number of texture fetches

	// -- Calculate the sharpening --
	float3 sharp = color - blur_ori;  //Subtracting the blurred image from the original image

	// -- Adjust strength of the sharpening and clamp it--
	float4 sharp_strength_luma_clamp = float4(sharp_strength_luma * (0.5 / sharp_clamp),0.5); //Roll part of the clamp into the dot

	//sharp_luma = saturate((0.5 / sharp_clamp) * sharp_luma + 0.5); //scale up and clamp
	float sharp_luma = saturate(dot(float4(sharp,1.0), sharp_strength_luma_clamp)); //Calculate the luma, adjust the strength, scale up and clamp
	sharp_luma = (sharp_clamp * 2.0) * sharp_luma - sharp_clamp; //scale down
    if (SharpenBefore) {
        // -- Combining the values to get the final sharpened pixel	--
	    color += sharp_luma;    // Add the sharpening to the the original.
    }
    
    // Gamma
    if (LinearGamma)
        color = GammaConvert::to_linear(color);

    color = pow(abs(color), rcp(Gamma));

    if (RGB_Gamma.x != Gamma || RGB_Gamma.y != Gamma || RGB_Gamma.z != Gamma) // apply gamma color tint
        color = pow(abs(color), rcp(RGB_Gamma));



    color = lerp( color, blendLuma( float3( 0.98f, 0.588f, 0.0f ), color ), 0.0f );
                                            
    // Contrast
    float3 c = sl( color, color );
    float con = ( contrast < 0.0f ) ? contrast * 0.5f : contrast;
    color = saturate( lerp( color, c, con ));

    // Brightness
    float3 d = 1.0f - ( 1.0f - color ) * ( 1.0f - color );
    float bri = ( brightness < 0.0f ) ? brightness * 0.5f : brightness;
    color = saturate( lerp( color, d, bri ));   

    // Vibrance
    float4 sat = 0.0f;
    sat.xy = float2( min( min( color.x, color.y ), color.z ), max( max( color.x, color.y ), color.z ));
    sat.z = sat.y - sat.x;
    sat.w = dot( color, float3( 0.212656, 0.715158, 0.072186 ));
    color = saturate( lerp( sat.w, color, 1.0f + ( vibrance * ( 1.0f - sat.z ))));



    if (!SharpenBefore) {
        // -- Combining the values to get the final sharpened pixel	--
	    color += sharp_luma;    // Add the sharpening to the the original.
    }
    

    return saturate(color);
}

technique ITTReshade
{
	pass
	{
		VertexShader = PostProcessVS;
		PixelShader = ITTReshadePass;
	}
}

















